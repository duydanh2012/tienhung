<section class="intro" id="intro">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <h2 class="h3">Portal</h2>
          <p class="text-big">Website <strong>tin tức nông nghiệp</strong> được cập nhật <strong>hằng ngày</strong>. Tin tức mới nhất trong ngày được báo Nông nghiệp Việt Nam  thông tin nhanh nhất 24h hàng ngày. Đọc báo tin tức online, cập nhật tin nóng thời sự.</p>
        </div>
      </div>
    </div>
  </section><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/intro.blade.php ENDPATH**/ ?>