<?php
    $comments = getCommentWithPost($post);
?>

<?php if($comments->count() > 0): ?>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="comment">
            <div class="comment-header d-flex justify-content-between">
                <div class="user d-flex align-items-center">
                    <div class="image"><img src="<?php echo e(asset('assets/images/app-logo.svg')); ?>" alt="<?php echo e($item->user->name); ?>" class="img-fluid rounded-circle"></div>
                    <div class="title"><strong><?php echo e($item->user->name); ?></strong><span class="date"><?php echo e(date("d/m/Y", strtotime($item->created_at) )); ?></span></div>
                </div>
            </div>
            <div class="comment-body">
                <p><?php echo e($item->comment); ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p class="none-comment">Không có bình luận</p>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/blog/comment.blade.php ENDPATH**/ ?>