<?php
  $posts = lastPost();
?>

<section class="latest-posts"> 
  <div class="container">
    <header> 
      <h2>Bài viết mới nhất</h2>
      <p class="text-big">Cùng nhau cập nhật những tin tức mới nhất!</p>
    </header>
    <div class="row">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post col-md-4">
          <div class="post-thumbnail"><a href="<?php echo e(getUrl($item)); ?>"><img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->name); ?>" class="img-fluid"></a></div>
          <div class="post-details">
            <div class="post-meta d-flex justify-content-between">
              <div class="date"><?php echo e(date("d/m/Y", strtotime($item->created_at))); ?></div>
              <div class="category"><?php echo e(getUser($item)); ?></div>
            </div><a href="<?php echo e(getUrl($item)); ?>">
              <h3 class="h4"><?php echo e($item->name); ?></h3></a>
            <p class="text-muted"><?php echo e($item->description); ?></p>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/last-post.blade.php ENDPATH**/ ?>