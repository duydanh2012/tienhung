
<?php $__env->startSection('title', 'Thêm bài viết'); ?>
<?php $__env->startSection('content'); ?>
<script src="https://cdn.ckeditor.com/4.12.1/standard/ckeditor.js"></script>
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">

            <h1 class="app-page-title">Thêm bài viết</h1>
            <hr class="mb-4">

            <div class="row g-4 settings-section">
                <div class="col-12 col-md-12">
                    <div class="app-card app-card-settings shadow-sm p-4">
                        <?php if(count($errors) >0): ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-danger"> <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <div class="app-card-body">
                            <form class="settings-form" action="<?php echo e(isset($data) ? route('posts.update', $data->id) : route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php if(isset($data)): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="setting-input-1" class="form-label">Tên:</label>
                                    <input type="text" name="name" class="form-control" id="setting-input-1"
                                        value="<?php echo e(isset($data) ? $data->name :  old('name')); ?>" placeholder="Tên danh mục" required>
                                </div>
                                <div class="mb-3">
                                    <label for="setting-input-2" class="form-label">Mô tả:</label>
                                    <textarea class="form-control" name="description" id="setting-input-2" rows="3" style="height: 100px"><?php echo e(isset($data) ? $data->description :  old('description')); ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="content" class="form-label">Nội dung bài viết:</label>
                                    <textarea class="form-control ckeditor" name="content" id="content"><?php echo isset($data) ? $data->content :  old('content'); ?></textarea>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="image" class="form-label">Hình ảnh</label>
                                            <?php if(isset($data)): ?>
                                                <p>
                                                    <img src="<?php echo e(asset($data->image)); ?>" alt="<?php echo e($data->image); ?>" style="max-width: 200px; max-height: 200px;">
                                                </p>
                                            <?php endif; ?>
                                            
                                            <input type="file" name="image" id="image" class="form-control" accept="image/*" >
                                        </div>
                                        <div class="form-check form-switch mb-3">
                                            <input class="form-check-input" name="is_featured" type="checkbox" id="settings-switch-1" <?php if((isset($data->is_featured) && $data->is_featured == 1)  || (old('is_featured') == 1)): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="settings-switch-1">Bài viết nổi bật</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Danh mục</label>
                                        <?php
                                            $value = [];
                                            if(isset($data)){
                                                $value = $data->categories->toArray();
                                            }
                                        ?>
                                        <?php if(count($categories) > 0): ?>
                                            <?php echo $__env->make('admin.posts.checkbox', ['data' => $categories, 'value' => $value], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <button type="submit" class="btn app-btn-primary">Save Changes</button>
                            </form>
                        </div>
                        <!--//app-card-body-->

                    </div>
                    <!--//app-card-->
                </div>
            </div>


        </div>
        <!--//container-fluid-->
    </div>
    <script type="text/javascript">
        CKEDITOR.replace('content', {
            filebrowserUploadUrl: "<?php echo e(route('ckeditor.upload', ['_token' => csrf_token() ])); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/admin/posts/form.blade.php ENDPATH**/ ?>