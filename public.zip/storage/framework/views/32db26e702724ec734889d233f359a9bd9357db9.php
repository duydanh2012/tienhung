
<?php $__env->startSection('title', 'Thêm danh mục'); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">

            <h1 class="app-page-title">Danh mục</h1>
            <hr class="mb-4">

            <div class="row g-4 settings-section">
                <div class="col-12 col-md-12">
                    <div class="app-card app-card-settings shadow-sm p-4">

                        <div class="app-card-body">
                            <form class="settings-form" action="<?php echo e(isset($data) ? route('categories.update', $data->id) : route('categories.store')); ?>" method="POST">
                                <?php if(isset($data)): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="setting-input-1" class="form-label">Tên:</label>
                                    <input type="text" name="name" class="form-control" id="setting-input-1"
                                        value="<?php echo e(isset($data) ? $data->name :  old('name')); ?>" placeholder="Tên danh mục" required>
                                </div>
                                <div class="mb-3">
                                    <label for="setting-input-2" class="form-label">Mô tả:</label>
                                    <textarea class="form-control" name="description" id="setting-input-2" rows="3" style="height: 100px">
                                        <?php echo e(isset($data) ? $data->description :  old('description')); ?>

                                    </textarea>
                                    
                                </div>
                                <div class="mb-3">
                                    <label for="setting-input-3" class="form-label">Danh mục cha</label>
                                    <select name="parent_id" id="parent_id" class="form-control">
                                        <option value="0">Không</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php echo e(isset($data) ? (($data->parent->id == $key) ? 'selected' : null ) : null); ?>><?php echo e($value); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" name="menu" type="checkbox" id="settings-switch-1" <?php if((isset($data->menu) && $data->menu == 1) || (old('menu') == 1)): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="settings-switch-1">Thêm vào menu</label>
                                </div>
                                <button type="submit" class="btn app-btn-primary">Save Changes</button>
                            </form>
                        </div>
                        <!--//app-card-body-->

                    </div>
                    <!--//app-card-->
                </div>
            </div>


        </div>
        <!--//container-fluid-->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/admin/categories/form.blade.php ENDPATH**/ ?>