<?php
    $pagination = $paginator->lastPage();
    $paginationCurrent = $paginator->currentPage();
    $sub = $pagination - $paginationCurrent;
?>

<?php if($pagination > 1): ?>
    <nav aria-label="Page navigation example">
        <ul class="pagination pagination-template d-flex justify-content-center">
            <li class="page-item <?php echo e(($paginationCurrent == 1) ? 'disabled' : NULL); ?>">
                <a href="<?php echo e($paginator->url($paginationCurrent - 1)); ?>" class="page-link"> <i class="fas fa-angle-left"></i>></a>
            </li>

            <?php if($pagination <= 3): ?>
                <?php for($i = 1; $i <= $pagination; $i++): ?>
                    <li class="page-item">
                        <a href="<?php echo e($paginator->url($i)); ?>" class="page-link <?php echo e(($paginationCurrent == $i) ? 'active' : NULL); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>
            <?php else: ?>
                <?php if($paginationCurrent == 1): ?>
                    <?php for($i = 1; $i <= ($paginationCurrent + 4); $i++): ?>
                        <li class="page-item">
                            <a href="<?php echo e($paginator->url($i)); ?>" class="page-link <?php echo e(($paginationCurrent == $i) ? 'active' : NULL); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                <?php elseif($sub < 4): ?>      
                    <?php for($i = ($paginationCurrent - 1); $i <= $pagination; $i++): ?>
                        <li class="page-item">
                            <a href="<?php echo e($paginator->url($i)); ?>" class="page-link <?php echo e(($paginationCurrent == $i) ? 'active' : NULL); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                <?php else: ?>
                    <?php for($i = ($paginationCurrent - 1); ($i <= ($paginationCurrent + 3) && $i <= $pagination); $i++): ?>
                        <li class="page-item">
                            <a href="<?php echo e($paginator->url($i)); ?>" class="page-link <?php echo e(($paginationCurrent == $i) ? 'active' : NULL); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                <?php endif; ?>    
            <?php endif; ?>

            <li class="page-item <?php echo e(($paginationCurrent == $pagination) ? 'disabled' : NULL); ?>"><a href="<?php echo e($paginator->url($paginationCurrent + 1)); ?>" class="page-link"> <i class="fas fa-angle-right"></i></a></li>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/layouts/pagination.blade.php ENDPATH**/ ?>