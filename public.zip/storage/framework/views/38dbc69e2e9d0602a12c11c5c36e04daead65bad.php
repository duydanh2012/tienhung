<main class="post blog-post col-lg-8">
    <div class="container">
        <div class="post-single">
            <?php if(!empty($data->image)): ?>
            <div class="post-thumbnail">
                <img src="<?php echo e(asset($data->image)); ?>" alt="<?php echo e($data->name); ?>" class="img-fluid">
            </div>
            <?php endif; ?>

            <div class="post-details">
                <div class="post-meta d-flex justify-content-between">
                    <?php if($data->categories->count() > 0): ?>
                    <div class="category">
                        <?php $__currentLoopData = $data->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(getUrl($category)); ?>"><?php echo e($category->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <h1><?php echo e($data->name); ?><a href="<?php echo e(getUrl($data)); ?>"><i class="far fa-bookmark"></i></a></h1>
                <div class="post-footer d-flex align-items-center flex-column flex-sm-row"><a href="javascript:void(0);"
                        class="author d-flex align-items-center flex-wrap">
                        <div class="title"><span><?php echo e(getUser($data)); ?></span></div>
                    </a>
                    <div class="d-flex align-items-center flex-wrap">
                        <div class="date"><i class="far fa-clock"></i> <?php echo e(date("d/m/Y", strtotime($data->created_at) )); ?></div>
                        <div class="views"><i class="far fa-eye"></i> <?php echo e($data->views); ?></div>
                        <div class="comments meta-last"><i class="fas fa-comment-alt"></i> <?php echo e(countComment($data->id)); ?>

                        </div>
                    </div>
                </div>
                <div class="post-body">
                    <p class="lead"><?php echo e($data->description); ?></p>
                    <?php echo $data->content; ?>

                </div>

                <div class="post-comments">
                    <header>
                        <h3 class="h6">Bình luận<span class="no-of-comments">(<?php echo e(countComment($data->id)); ?>)</span></h3>
                    </header>

                    <?php echo $__env->make('public.partials.blog.comment', ['post' => $data->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <?php if(Auth::check()): ?>
                    <div class="add-comment">
                        <header>
                            <h3 class="h6">Viết bình luận</h3>
                        </header>
                        <form action="<?php echo e(route('public.comment', $data->id)); ?>" method="POST" class="commenting-form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <textarea name="comment" id="comment" placeholder="Nhập bình luận"
                                        class="form-control"></textarea>
                                </div>
                                <div class="form-group col-md-12">
                                    <a class="btn btn-secondary submitComment text-white">Submit Comment</a>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="add-comment">
                        <a href="<?php echo e(route('public.login')); ?>"><h3 class="h6">Đăng nhập để viết bình luận</h3></a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>
<script src="<?php echo e(asset('assets/js/comment.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/blog/post.blade.php ENDPATH**/ ?>