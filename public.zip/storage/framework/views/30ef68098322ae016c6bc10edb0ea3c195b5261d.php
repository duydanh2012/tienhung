<?php
    $pagination = $paginator->lastPage();
    $paginationCurrent = $paginator->currentPage();
    $sub = $pagination - $paginationCurrent;
?>

<nav class="app-pagination">
    <?php if($pagination > 1): ?>
        <ul class="pagination justify-content-center">
            <li class="page-item <?php echo e(($paginationCurrent == 1) ? 'disabled' : NULL); ?>">
                <a class="page-link" href="<?php echo e($paginator->url($paginationCurrent - 1)); ?>" tabindex="-1" aria-disabled="true">Previous</a>
            </li>

            <?php if($pagination <= 5): ?>
                <?php for($i = 1; $i <= $pagination; $i++): ?>
                    <li class="page-item <?php echo e(($paginationCurrent == $i) ? 'active' : NULL); ?>"><a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e(($i < 10) ? '0' . $i : $i); ?></a></li>
                <?php endfor; ?>
            <?php else: ?>
                <?php if($paginationCurrent == 1): ?>
                    <?php for($i = 1; $i <= ($paginationCurrent + 4); $i++): ?>
                        <li class="page-item <?php echo e(($paginationCurrent == $i) ? 'active' : NULL); ?>"><a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e(($i < 10) ? '0' . $i : $i); ?></a></li>
                    <?php endfor; ?>
                <?php elseif($sub < 4): ?>
                    <?php for($i = ($paginationCurrent - 1); $i <= $pagination; $i++): ?>
                        <li class="page-item <?php echo e(($paginationCurrent == $i) ? 'active' : NULL); ?>"><a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e(($i < 10) ? '0' . $i : $i); ?></a></li>
                    <?php endfor; ?>
                <?php else: ?>
                    <?php for($i = ($paginationCurrent - 1); ($i <= ($paginationCurrent + 3) && $i <= $pagination); $i++): ?>
                        <li class="page-item <?php echo e(($paginationCurrent == $i) ? 'active' : NULL); ?>"><a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e(($i < 10) ? '0' . $i : $i); ?></a></li>
                    <?php endfor; ?>
                <?php endif; ?>
            <?php endif; ?>

            <li class="page-item <?php echo e(($paginationCurrent == $pagination) ? 'disabled' : NULL); ?>">
                <a class="page-link" href="<?php echo e($paginator->url($paginationCurrent + 1)); ?>">Next</a>
            </li>
        </ul>
    <?php endif; ?>    
</nav><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/layouts/paginator.blade.php ENDPATH**/ ?>