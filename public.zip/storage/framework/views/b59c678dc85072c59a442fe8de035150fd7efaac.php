<?php
    $value = isset($value) ? $value : [];
?>
<?php if($data): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="category[]" value="<?php echo e($item->id); ?>" id="checkbox-<?php echo e($item->id); ?>" <?php echo e(in_array($item->id, array_column($value, 'id')) ? "checked" : NULL); ?>>
            <label class="form-check-label" for="checkbox-<?php echo e($item->id); ?>">
                <?php echo e($item->name); ?>

            </label>
            <?php echo $__env->make('admin.posts.checkbox', ['data' => $item->child_cats, 'value' => $value], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\tienhung\resources\views/admin/posts/checkbox.blade.php ENDPATH**/ ?>