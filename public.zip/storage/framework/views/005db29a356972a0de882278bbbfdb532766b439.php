<?php
  $data = countPostWithCategory();
?>

<div class="widget categories">
    <header>
      <h3 class="h6">Danh mục</h3>
    </header>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="item d-flex justify-content-between">
          <a href="<?php echo e(getUrl($item)); ?>"><?php echo e($item->name); ?></a><span><?php echo e($item->count); ?></span>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/blog/categories.blade.php ENDPATH**/ ?>