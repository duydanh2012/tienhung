<?php
  $featurePosts = featuredPost();
?>

<section class="featured-posts no-padding-top">
    <div class="container">
      <?php $__currentLoopData = $featurePosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->index % 2 == 0): ?>
          <div class="row d-flex align-items-stretch">
            <div class="text col-lg-7">
              <div class="text-inner d-flex align-items-center">
                <div class="content">
                  <header class="post-header">
                    <div class="category">
                      <?php if($item->categories->count() > 0): ?>
                        <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="<?php echo e(getUrl($category)); ?>"><?php echo e($category->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </div>

                    <a href="<?php echo e(getUrl($item)); ?>">
                      <h2 class="h4"><?php echo e($item->name); ?></h2>
                    </a>
                  </header>
                  <p><?php echo e($item->description); ?></p>
                  <footer class="post-footer d-flex align-items-center"><a href="#" class="author d-flex align-items-center flex-wrap">
                      <div class="title"><span><?php echo e(getUser($item)); ?></span></div></a>
                    <div class="date"><i class="far fa-clock"></i> <?php echo e(date("d/m/Y", strtotime($item->created_at) )); ?></div>
                    <div class="comments"><i class="fas fa-comment-alt"></i> <?php echo e(countComment($item->id)); ?></div>
                  </footer>
                </div>
              </div>
            </div>
            <div class="image col-lg-5"><img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->name); ?>"></div>
          </div>
        <?php else: ?>
          <div class="row d-flex align-items-stretch">
            <div class="image col-lg-5"><img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->name); ?>"></div>
            <div class="text col-lg-7">
              <div class="text-inner d-flex align-items-center">
                <div class="content">
                  <header class="post-header">
                    <div class="category">
                      <?php if($item->categories->count() > 0): ?>
                        <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="<?php echo e(getUrl($category)); ?>"><?php echo e($category->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </div>

                    <a href="<?php echo e(getUrl($item)); ?>">
                      <h2 class="h4"><?php echo e($item->name); ?></h2>
                    </a>
                  </header>
                  <p><?php echo e($item->description); ?></p>
                  <footer class="post-footer d-flex align-items-center"><a href="#" class="author d-flex align-items-center flex-wrap">
                      <div class="title"><span><?php echo e(getUser($item)); ?></span></div></a>
                    <div class="date"><i class="far fa-clock"></i> <?php echo e(date("d/m/Y", strtotime($item->created_at) )); ?></div>
                    <div class="comments"><i class="fas fa-comment-alt"></i></i> 12</div>
                  </footer>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!-- Post-->
    </div>
  </section><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/featured-post.blade.php ENDPATH**/ ?>