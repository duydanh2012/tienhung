<?php
  $posts = lastPost(4);
?>

<section class="gallery no-padding">    
      <div class="row">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="mix col-lg-3 col-md-3 col-sm-6">
            <div class="item"><a href="<?php echo e(asset($item->image)); ?>" data-fancybox="gallery" class="image"><img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->name); ?>" class="img-fluid">
                <div class="overlay d-flex align-items-center justify-content-center"><i class="fas fa-search"></i></div></a></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </section><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/gallery.blade.php ENDPATH**/ ?>