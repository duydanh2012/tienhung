<?php
  $posts = lastPost();
?>

<div class="widget latest-posts">
    <header>
      <h3 class="h6">Bài viết mới nhất</h3>
    </header>
    <div class="blog-posts">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(getUrl($item)); ?>">
          <div class="item d-flex align-items-center">
            <div class="image"><img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->name); ?>" class="img-fluid"></div>
            <div class="title"><strong><?php echo e($item->name); ?></strong>
              <div class="d-flex align-items-center">
                <div class="views"><i class="far fa-eye"></i> <?php echo e($item->views); ?></div>
                <div class="comments"><i class="fas fa-comment-alt"></i> <?php echo e(countComment($item->id)); ?></div>
              </div>
            </div>
          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/blog/last-posts.blade.php ENDPATH**/ ?>