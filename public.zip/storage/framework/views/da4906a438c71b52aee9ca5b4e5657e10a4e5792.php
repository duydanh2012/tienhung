
<?php $__env->startSection('title', isset($category) ? $category->name : 'Tin tức'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php if(isset($category)): ?>
                <?php echo $__env->make('public.partials.blog.list-post', ['category' => $category, 'data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('public.partials.blog.list-post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php echo $__env->make('public.partials.blog.widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/views/blog.blade.php ENDPATH**/ ?>