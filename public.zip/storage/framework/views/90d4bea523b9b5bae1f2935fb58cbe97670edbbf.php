<?php
  if(isset($category)){
    $posts = $data;
  }else{
    $posts = getAllPosts();
  }
?>

<main class="posts-listing col-lg-8">
  <div class="container">
    <?php if(isset($category)): ?>
    <h1><?php echo e($category->name); ?></h1>
    <?php endif; ?>
    
      <div class="row">
          <!-- post -->
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post col-xl-6">
                <div class="post-thumbnail"><a href="<?php echo e(getUrl($item)); ?>"><img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->name); ?>"
                            class="img-fluid"></a></div>
                <div class="post-details mt-2">
                    <a href="<?php echo e(getUrl($item)); ?>">
                        <h3 class="h4"><?php echo e($item->name); ?></h3>
                    </a>
                    <p class="text-muted"><?php echo e($item->description); ?></p>
                    <footer class="post-footer d-flex align-items-center">
                        <div class="title"><span><?php echo e(getUser($item)); ?></span></div>
                        <div class="date"><i class="far fa-clock"></i> <?php echo e(date("d/m/Y", strtotime($item->created_at) )); ?></div>
                        <div class="comments meta-last"><i class="fas fa-comment-alt"></i> <?php echo e(countComment($item->id)); ?></div>
                    </footer>
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <!-- Pagination -->
      <?php echo e($posts->links('public.layouts.pagination')); ?>

  </div>
</main><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/blog/list-post.blade.php ENDPATH**/ ?>