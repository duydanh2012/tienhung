
<?php $__env->startSection('title', 'Thêm danh mục'); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content pt-3 p-md-3 p-lg-4">
        <div class="container-xl">

            <h1 class="app-page-title">Danh mục</h1>
            <hr class="mb-4">

            <div class="row g-4 settings-section">
                <div class="col-12 col-md-12">
                    <div class="app-card app-card-settings shadow-sm p-4">
                        <?php if(count($errors) >0): ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-danger"> <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <?php if(session('alert_error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('alert_error')); ?>

                            </div>
                        <?php elseif(session('alert_success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('alert_success')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="app-card-body">
                            <form class="settings-form" action="<?php echo e(isset($data) ? route('users.update', $data->id) : route('users.store')); ?>" method="POST">
                                <?php if(isset($data)): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="setting-input-1" class="form-label">Tên:</label>
                                    <input type="text" name="name" class="form-control" id="setting-input-1"
                                        value="<?php echo e(isset($data) ? $data->name :  old('name')); ?>" placeholder="Họ và tên" required>
                                </div>
                                <div class="mb-3">
                                    <label for="setting-input-2" class="form-label">Email:</label>
                                    <input type="email" name="email" class="form-control" id="setting-input-2"
                                        value="<?php echo e(isset($data) ? $data->email :  old('email')); ?>" placeholder="Email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="setting-input-3" class="form-label">Số điện thoại</label>
                                    <div class="row">
                                        <div class="col-1">
                                            <p class="form-control">
                                                +84
                                            </p>
                                        </div>
                                        <div class="col-11">
                                            <input type="text" name="phone" class="form-control" id="setting-input-3"
                                                value="<?php echo e(isset($data) ? $data->phone :  old('phone')); ?>" placeholder="Số điện thoại" maxlength="9">
                                        </div>
                                    </div>
                                    
                                </div>

                                <?php if(!isset($data)): ?>
                                    <div class="mb-3">
                                        <label for="setting-input-4" class="form-label">Password:</label>
                                        <input type="password" name="password" class="form-control" id="setting-input-4"
                                            value="<?php echo e(isset($data) ? $data->password :  old('password')); ?>" placeholder="Nhập mật khẩu">
                                    </div>                               
                                <?php endif; ?>

                                <div class="mb-3">
                                    <label for="admin" class="form-label">Quyền quản trị viên</label>
                                    <select name="admin" id="admin" class="form-control">
                                        <option value="0">Không</option>
                                        <option value="1" <?php if(isset($data) && ($data->admin == 1)): ?> selected <?php endif; ?>>Quản trị viên</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn app-btn-primary">Save Changes</button>
                                <?php if(isset($data)): ?>
                                    <a href="<?php echo e(route('users.forget', $data->id)); ?>" class="btn app-btn-secondary">Reset Mật khẩu</a>
                                <?php endif; ?>
                            </form>
                        </div>
                        <!--//app-card-body-->

                    </div>
                    <!--//app-card-->
                </div>
            </div>


        </div>
        <!--//container-fluid-->
    </div>
    <script>
        $(document).ready(function(){
            $('input[name="phone"]').keyup(function(e)
            {
                if (/\D/g.test(this.value))
                {

                    this.value = this.value.replace(/\D/g, '');
                }
            });
        })

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/admin/users/form.blade.php ENDPATH**/ ?>