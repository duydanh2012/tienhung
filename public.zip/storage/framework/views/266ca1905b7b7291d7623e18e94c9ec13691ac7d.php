<aside class="col-lg-4">
    <?php echo $__env->make('public.partials.blog.last-posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('public.partials.blog.categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</aside>    <?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/blog/widget.blade.php ENDPATH**/ ?>