<div class="comment-header d-flex justify-content-between">
    <div class="user d-flex align-items-center">
        <div class="image"><img src="<?php echo e(asset('assets/images/app-logo.svg')); ?>" alt="<?php echo e($comment->user); ?>" class="img-fluid rounded-circle"></div>
        <div class="title"><strong><?php echo e($comment->user); ?></strong><span class="date"><?php echo e(date("d/m/Y", strtotime($comment->created_at) )); ?></span></div>
    </div>
</div>
<div class="comment-body">
    <p><?php echo e($comment->comment); ?></p>
</div><?php /**PATH C:\xampp\htdocs\tienhung\resources\views/public/partials/blog/addComment.blade.php ENDPATH**/ ?>