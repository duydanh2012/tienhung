<section style="background: url({{ asset('images/69991210_2996084333795709_4072989616477569024_n.jpg') }}); background-size: cover; background-position: center center" class="hero">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <h1>Portal - Website tin tức nông nghiệp hàng đầu Việt Nam</h1><a href="#" class="hero-link">Khám phá</a>
        </div>
      </div><a href="#intro" class="continue link-scroll"><i class="fas fa-long-arrow-alt-down"></i> Scroll Down</a>
    </div>
  </section>