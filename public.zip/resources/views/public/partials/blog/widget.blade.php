<aside class="col-lg-4">
    @include('public.partials.blog.last-posts')
    @include('public.partials.blog.categories')
</aside>    